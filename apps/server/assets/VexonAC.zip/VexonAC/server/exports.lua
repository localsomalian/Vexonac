-- ============================================================
--  VexonAC | resource/server/exports.lua
--  Detection engine, scoring, config fetch, panel reporting
-- ============================================================

local scores             = {}   -- [src] = { score, dets, rates, kicked }
local explosions         = {}   -- [src] = { count, reset }
local entities           = {}   -- [src] = { count, reset }
local heartbeats         = {}   -- [src] = { pos, health, speed, ts }
local eventRates         = {}   -- [src][event] = { count, window }
local joinTimes          = {}   -- [src] = GetGameTimer()  (for playtime tracking)
local pendingEvidenceUrls = {}  -- [src] = screenshot CDN URL waiting for ban
local lastScreenshotTime  = {}  -- [src] = GetGameTimer()  (screenshot cooldown)
local SCREENSHOT_COOLDOWN = 25000  -- 25 seconds between screenshots per player

local INGRESS_URL = GetConvar("vexonac_ingress_url", "https://ingress.vexonac.com")
-- Read license key from auth/license.txt (auto-populated on download); fall back to convar for manual override
local _authKey = (LoadResourceFile(GetCurrentResourceName(), "auth/license.txt") or ""):gsub("^%s*(.-)%s*$", "%1")
local INGRESS_KEY = (_authKey ~= "") and _authKey or GetConvar("vexonac_ingress_key", "")

-- ── Panel HTTP ────────────────────────────────────────────────

local function PostToPanel(path, body)
    if INGRESS_KEY == "" then return end
    PerformHttpRequest(INGRESS_URL .. path, function() end, "POST",
        json.encode(body),
        {
            ["Content-Type"] = "application/json",
            ["X-API-Key"]    = INGRESS_KEY,
            ["User-Agent"]   = "AYZNNNISTHEBEST",
        }
    )
end

local function GetToPanel(path, cb)
    if INGRESS_KEY == "" then return end
    PerformHttpRequest(INGRESS_URL .. path, function(status, body)
        if status == 200 and body then
            local ok, data = pcall(json.decode, body)
            if ok and data then cb(data) end
        end
    end, "GET", "", { ["Content-Type"] = "application/json", ["User-Agent"] = "AYZNNNISTHEBEST" })
end

local function GetIdentifiers(src)
    local ids = {}
    for i = 0, GetNumPlayerIdentifiers(src) - 1 do
        table.insert(ids, GetPlayerIdentifier(src, i))
    end
    return ids
end

-- ── Apply panel configuration ────────────────────────────────

local function ApplyConfig(cfg)
    if not cfg then return end

    local main = cfg.Main or {}
    local sets = cfg.Settings or {}

    -- ── Push FULL config into auth.lua system ─────────────────
    -- VexonAC.MakeConfiguration reads the raw config table (same format the
    -- panel returns) and sets VexonAC.Config + VexonAC.WebHooks.  After that
    -- __VexonAC_internal:configUpdated post-processes hash lists so all the
    -- toggle switches, blacklists, webhooks, etc. take effect immediately.
    if VexonAC.MakeConfiguration then
        _G.RawVexonACConfiguration = cfg
        VexonAC.MakeConfiguration(cfg)
        TriggerEvent("__VexonAC_internal:configUpdated")
        _G.RawVexonACConfiguration = nil
    end

    -- ── Speed limits (our detection engine, separate from auth.lua) ───
    if cfg.Premium and cfg.Premium.CustomSpeedLimits then
        if cfg.Premium.FootSpeedLimit   and cfg.Premium.FootSpeedLimit   > 0 then VexonAC.MaxSpeed.onFoot  = cfg.Premium.FootSpeedLimit  end
        if cfg.Premium.VehicleSpeedLimit and cfg.Premium.VehicleSpeedLimit > 0 then VexonAC.MaxSpeed.vehicle = cfg.Premium.VehicleSpeedLimit end
    end

    -- ── Score thresholds ─────────────────────────────────────────────
    if sets.KickScore       then VexonAC.Thresholds.KICK       = sets.KickScore       end
    if sets.TempBanScore    then VexonAC.Thresholds.TEMP_BAN   = sets.TempBanScore    end
    if sets.PermBanScore    then VexonAC.Thresholds.PERM_BAN   = sets.PermBanScore    end
    if sets.ScreenshotScore then VexonAC.Thresholds.SCREENSHOT = sets.ScreenshotScore end

    if sets.EnableBans == false then
        VexonAC.Thresholds.PERM_BAN = 999999
        VexonAC.Thresholds.TEMP_BAN = 999999
    end

    if sets.BanDuration then VexonAC.BanDuration = sets.BanDuration end

    -- ── Discord webhooks — keep waveshield VexonAC.WebHooks in sync ──
    -- VexonAC.MakeConfiguration already set VexonAC.WebHooks directly.
    -- Also fire __VexonAC:webhooksUpdated so the compiled webhook handler
    -- re-caches all category webhooks (Entities, Weapons, etc.) for live updates.
    local webhookPayload = json.encode({
        MainWebhook          = sets.MainWebhook           or "",
        EntitiesWebhook      = sets.EntitiesWebhook       or "",
        ExplosionsWebhook    = sets.ExplosionsWebhook     or "",
        WeaponsWebhook       = sets.WeaponsWebhook        or "",
        UnbansWebhook        = sets.UnbansWebhook         or "",
        ConnectionsWebhook   = sets.ConnectionsWebhook    or "",
        CommunityLogsWebhook = sets.CommunityLogsWebhook  or "",
        GlobalBanWebhook     = sets.GlobalBanWebhook      or "",
        ScreenshotsWebhook   = sets.ScreenshotsWebhook    or "",
    })
    TriggerEvent("__VexonAC:webhooksUpdated", webhookPayload)
    if sets.MainWebhook and sets.MainWebhook ~= "" then
        VexonAC.DiscordWebhook = sets.MainWebhook
    end

    -- ── Sync weapon blacklist from panel config into our detection table ─
    local weps = cfg.Weapons or {}
    if weps.BlackListedWeapons and type(weps.BlackListedWeapons) == "table" then
        VexonAC.BlacklistedWeapons = {}  -- reset then rebuild from config
        for _, wepName in ipairs(weps.BlackListedWeapons) do
            local upper = wepName:upper():gsub("WEAPON_", "")
            local hash  = GetHashKey(wepName)
            if hash and hash ~= 0 then
                VexonAC.BlacklistedWeapons[upper] = hash
            end
        end
    end

    -- ── Sync vehicle blacklist from panel config into our detection table ─
    local ents = cfg.Entities or {}
    if ents.BlackListedVehicles and type(ents.BlackListedVehicles) == "table" and #ents.BlackListedVehicles > 0 then
        VexonAC.BlacklistedVehicles = {}  -- reset then rebuild from config
        for _, vehName in ipairs(ents.BlackListedVehicles) do
            local hash = GetHashKey(vehName)
            if hash and hash ~= 0 then
                local upper = vehName:upper()
                VexonAC.BlacklistedVehicles[upper] = hash
            end
        end
    end

    -- ── Detection gates: zero-out pts for disabled checks ────────────
    if main.AntiTeleport  == false then VexonAC.Det.TELEPORT.pts   = 0 end
    if main.AntiNoClip    == false then VexonAC.Det.NOCLIP.pts     = 0 end
    if main.AntiSpeedHack == false then VexonAC.Det.SPEED_HACK.pts = 0 end
    if main.AntiFreeCam   == false then VexonAC.Det.FREECAM.pts    = 0 end
    if main.AntiGodMode   == false then VexonAC.Det.GODMODE.pts    = 0 end
    if main.AntiAimbot    == false then VexonAC.Det.AIMBOT.pts     = 0 end
    if main.AntiInvisible == false then VexonAC.Det.INVISIBLE.pts  = 0 end
    if main.AntiSuperJump == false then VexonAC.Det.SUPER_JUMP.pts = 0 end
    if main.AntiInvincible == false then VexonAC.Det.INVINCIBLE.pts = 0 end
end

-- ── Fetch config from panel ───────────────────────────────────

-- ── Apply adaptive calibration weights ───────────────────────
-- Reduces detection points for codes with recorded false positives.
-- Each FP recorded reduces the weight by 10% (max 50% reduction).

local function ApplyCalibration(cal)
    if not cal then return end
    for code, fpCount in pairs(cal) do
        if VexonAC.Det[code] and type(fpCount) == "number" and fpCount > 0 then
            local base = VexonAC.Det[code]._basePts or VexonAC.Det[code].pts
            VexonAC.Det[code]._basePts = base
            local reduction = math.min(0.5, fpCount * 0.10)  -- max 50% reduction
            VexonAC.Det[code].pts = math.floor(base * (1.0 - reduction))
        end
    end
end

local function FetchConfig()
    if INGRESS_KEY == "" then return end
    GetToPanel("/api/license/" .. INGRESS_KEY .. "/config", function(data)
        if data and data.configuration then
            ApplyConfig(data.configuration)
        end
        if data and data.calibration then
            ApplyCalibration(data.calibration)
        end
    end)
end

-- ── Screenshot helper (rate-limited) ─────────────────────────

local function TakeScreenshot(src)
    local now = GetGameTimer()
    local last = lastScreenshotTime[src] or 0
    if (now - last) < SCREENSHOT_COOLDOWN then return end
    lastScreenshotTime[src] = now
    TriggerClientEvent("vexonac:requestScreenshot", src, {
        id        = os.time(),
        uploadUrl = INGRESS_URL .. "/fivem/screenshot",
        key       = INGRESS_KEY,
    })
end

-- ── Player score state ────────────────────────────────────────

local function GetState(src)
    if not scores[src] then
        scores[src] = {
            score  = 0,
            dets   = {},
            rates  = {},
            kicked = false,
        }
    end
    return scores[src]
end

-- ── Score a detection ─────────────────────────────────────────

function Score(src, code, pts, evidence)
    if pts == 0 then return end  -- detection disabled by config
    if not GetPlayerName(src) then return end  -- player already disconnected
    if VexonAC.IsTrusted and VexonAC.IsTrusted(src) then return end  -- trusted player bypass

    local state = GetState(src)
    local now   = GetGameTimer()

    local r = state.rates[code] or { count = 0, window = now }
    if (now - r.window) > 60000 then
        r.count = 1; r.window = now
    else
        r.count = r.count + 1
        if r.count > 3 then pts = math.max(1, math.floor(pts * 0.5)) end
    end
    state.rates[code] = r

    state.score = state.score + pts

    local det = {
        code       = code,
        pts        = pts,
        evidence   = evidence or {},
        ts         = os.time(),
        totalScore = state.score,
    }
    table.insert(state.dets, det)
    if #state.dets > 100 then table.remove(state.dets, 1) end

    local name      = GetPlayerName(src)
    local savedIds  = GetIdentifiers(src)
    local det_info  = VexonAC.Det[code]
    local severity  = det_info and det_info.sev or "LOW"

    print(("[VexonAC] %s | %s +%d pts (total: %d)"):format(name, code, pts, state.score))

    -- Screenshot: always on CRITICAL, rate-limited otherwise
    if severity == "CRITICAL" then
        TriggerClientEvent("vexonac:requestScreenshot", src, {
            id        = os.time(),
            uploadUrl = INGRESS_URL .. "/fivem/screenshot",
            key       = INGRESS_KEY,
        })
        lastScreenshotTime[src] = GetGameTimer()
    else
        TakeScreenshot(src)
    end

    -- Post to panel: CRITICAL = 3s delay (fast), others = 7s (more screenshot upload time)
    local postDelay = (severity == "CRITICAL") and 3000 or 7000
    Citizen.SetTimeout(postDelay, function()
        PostToPanel("/fivem/detection", {
            playerName    = name,
            identifiers   = savedIds,
            detection     = det,
            screenshotUrl = pendingEvidenceUrls[src],
        })
    end)

    if det_info and det_info.autoBan then
        -- Kick immediately, ban after screenshot uploads
        DropPlayer(src, "[VexonAC] Banned: " .. code)
        Citizen.SetTimeout(5000, function()
            scores[src] = nil
            local ev = pendingEvidenceUrls[src]; pendingEvidenceUrls[src] = nil
            VexonAC.IssueBan(src, "[VexonAC] Auto-ban: " .. code, nil, "VexonAC Auto", ev)
        end)
        return
    end

    if state.score >= VexonAC.Thresholds.PERM_BAN then
        Citizen.SetTimeout(5000, function()
            if not GetPlayerName(src) then return end
            VexonAC.BanPlayer(src, "[VexonAC] Score " .. state.score .. " — permanent ban (" .. code .. ")")
        end)
    elseif state.score >= VexonAC.Thresholds.TEMP_BAN then
        Citizen.SetTimeout(5000, function()
            if not GetPlayerName(src) then return end
            VexonAC.BanPlayer(src, "[VexonAC] Score " .. state.score .. " — removed from server (" .. code .. ")")
        end)
    elseif state.score >= VexonAC.Thresholds.KICK and not state.kicked then
        state.kicked = true
        DropPlayer(src, "[VexonAC] Suspicious activity detected — score: " .. state.score .. " (" .. code .. ")")
    end
end

-- ── Screenshot upload callback ────────────────────────────────

RegisterNetEvent("vexonac:screenshotUploaded")
AddEventHandler("vexonac:screenshotUploaded", function(detId, rawData)
    local src = source
    if not src or src == 0 then return end

    local url = nil
    if type(rawData) == "string" then
        local ok, data = pcall(json.decode, rawData)
        if ok and data then
            url = data.url or (data.attachments and data.attachments[1] and data.attachments[1].url)
        end
    elseif type(rawData) == "table" then
        url = rawData.url or (rawData.attachments and rawData.attachments[1] and rawData.attachments[1].url)
    end

    if url and url ~= "" then
        pendingEvidenceUrls[src] = url
        print(("[VexonAC] Evidence screenshot stored for %s"):format(GetPlayerName(src) or tostring(src)))
    end
end)

-- ── Ban helper ────────────────────────────────────────────────

function VexonAC.BanPlayer(src, reason)
    -- Clear score state immediately so in-flight events don't re-trigger bans.
    scores[src] = nil

    -- Grab any cached screenshot URL and clear it before handing off to IssueBan.
    local evidenceUrl = pendingEvidenceUrls[src]
    pendingEvidenceUrls[src] = nil

    VexonAC.IssueBan(src, reason, nil, "VexonAC Auto", evidenceUrl)
end

-- ── Save playtime + fire leave webhook on disconnect ──────────

AddEventHandler("playerDropped", function(reason)
    local src = source
    if not src or src == 0 then return end

    -- Calculate time online in minutes
    local joinTime = joinTimes[src]
    if joinTime and INGRESS_KEY ~= "" then
        local license = GetPlayerIdentifier(src, 0) or ""
        local elapsed = math.floor((GetGameTimer() - joinTime) / 60000)
        if elapsed > 0 and license ~= "" then
            PerformHttpRequest(
                INGRESS_URL .. "/api/license/" .. INGRESS_KEY .. "/savePlayTime",
                function() end,
                "POST",
                json.encode({ playerLicense = license, timeOnline = elapsed }),
                {
                    ["Content-Type"]     = "application/json",
                    ["User-Agent"]       = "FXServer",
                }
            )
        end
    end

    -- Fire leave notification via panel
    local name    = GetPlayerName(src) or "Unknown"
    local license = GetPlayerIdentifier(src, 0) or ""
    if license ~= "" then
        PostToPanel("/fivem/leave", {
            playerName    = name,
            playerLicense = license,
            identifiers   = GetIdentifiers(src),
        })
    end

    -- Cleanup state
    scores[src]              = nil
    explosions[src]          = nil
    entities[src]            = nil
    heartbeats[src]          = nil
    eventRates[src]          = nil
    joinTimes[src]           = nil
    pendingEvidenceUrls[src] = nil
    lastScreenshotTime[src]  = nil
end)

-- ── Track join time + fire join webhook ───────────────────────

AddEventHandler("playerJoining", function()
    local src = source
    if not src or src == 0 then return end
    joinTimes[src] = GetGameTimer()
    -- Send join notification to panel for Discord webhook
    Citizen.SetTimeout(3000, function()
        local pName    = GetPlayerName(src) or "Unknown"
        local license  = GetPlayerIdentifier(src, 0) or ""
        local ids      = GetIdentifiers(src)
        if license ~= "" then
            PostToPanel("/fivem/join", {
                playerName    = pName,
                playerLicense = license,
                identifiers   = ids,
            })
        end
    end)
end)

-- ── Client detection event ────────────────────────────────────

RegisterNetEvent("vexonac:detection")
AddEventHandler("vexonac:detection", function(data)
    local src = source
    if not src or src == 0 then return end

    local code = data and data.code
    if not code or not VexonAC.Det[code] then return end

    -- Always use server-side pts (includes calibration adjustments)
    -- Ignoring client-provided pts prevents cheaters from manipulating
    -- their own score and ensures calibration actually takes effect.
    local det = VexonAC.Det[code]
    Score(src, code, det.pts, data.evidence)
end)

-- ── Heartbeat + server-side validation ───────────────────────

RegisterNetEvent("vexonac:heartbeat")
AddEventHandler("vexonac:heartbeat", function(data)
    local src = source
    if not src or src == 0 or not data then return end

    local prev = heartbeats[src]
    heartbeats[src] = { pos = data.pos, health = data.health, speed = data.speed, ts = os.time() }

    if not prev then return end

    local spd = data.speed or 0
    if spd > VexonAC.MaxSpeed.aircraft * 1.5 then
        Score(src, "SPEED_HACK", VexonAC.Det.SPEED_HACK.pts, { speed = spd, source = "heartbeat" })
    end

    if prev.pos and data.pos then
        local d = math.sqrt(
            (data.pos.x - prev.pos.x)^2 +
            (data.pos.y - prev.pos.y)^2 +
            (data.pos.z - prev.pos.z)^2
        )
        if d > 5000 then
            Score(src, "TELEPORT", VexonAC.Det.TELEPORT.pts, { dist = math.floor(d), source = "heartbeat" })
        end
    end
end)

-- ── Explosion monitoring ──────────────────────────────────────

AddEventHandler("explosionEvent", function(sender, ev)
    if sender == 0 then return end

    if not explosions[sender] then
        explosions[sender] = { count = 0, reset = GetGameTimer() }
    end
    local e = explosions[sender]

    if (GetGameTimer() - e.reset) > 60000 then e.count = 0; e.reset = GetGameTimer() end
    e.count = e.count + 1

    if e.count > VexonAC.MaxExplosionsPerMin then
        Score(sender, "EXPLOSION_SPAM", VexonAC.Det.EXPLOSION_SPAM.pts, {
            count = e.count,
            type  = ev.explosionType,
            pos   = ev.posX and { x = ev.posX, y = ev.posY, z = ev.posZ },
        })
        e.count = 0
    end
end)

-- ── Entity spam ───────────────────────────────────────────────

AddEventHandler("entityCreating", function(handle)
    local src = source
    if not src or src == 0 then return end

    if not entities[src] then entities[src] = { count = 0, reset = GetGameTimer() } end
    local e = entities[src]

    if (GetGameTimer() - e.reset) > 60000 then e.count = 0; e.reset = GetGameTimer() end
    e.count = e.count + 1

    if e.count > VexonAC.MaxEntitiesPerMin then
        Score(src, "ENTITY_SPAM", VexonAC.Det.ENTITY_SPAM.pts, { count = e.count })
        e.count = 0
    end
end)

-- ── Net event rate limiting ───────────────────────────────────

local function TrackNetEvent(src, eventName)
    if not eventRates[src] then eventRates[src] = {} end
    local rates = eventRates[src]
    local now   = GetGameTimer()

    if not rates[eventName] then rates[eventName] = { count = 0, window = now } end
    local r = rates[eventName]

    if (now - r.window) > 1000 then r.count = 0; r.window = now end
    r.count = r.count + 1

    if r.count > VexonAC.MaxNetEventsPerSec then
        Score(src, "NET_FLOOD", VexonAC.Det.NET_FLOOD.pts, { event = eventName, rate = r.count })
        return true
    end
    return false
end

-- weaponDamageEvent is rate-limited by events.lua (RateLimit); only track remaining events here
for _, evName in ipairs({ "explosionEvent", "entityCreating" }) do
    AddEventHandler(evName, function()
        TrackNetEvent(source, evName)
    end)
end

-- ── Reload config on panel update ────────────────────────────

AddEventHandler("vexonac:configUpdate", function()
    FetchConfig()
end)

-- ── Blacklisted weapon: remove weapon, screenshot, then ban ──────

RegisterNetEvent("vexonac:blacklistWeaponBan")
AddEventHandler("vexonac:blacklistWeaponBan", function(data)
    local src = source
    if not src or src == 0 then return end

    local name = GetPlayerName(src)
    if not name then return end

    -- Screenshot first (force: bypass cooldown since this is always a ban)
    lastScreenshotTime[src] = 0
    TakeScreenshot(src)

    -- Ban after giving the screenshot time to upload
    Citizen.SetTimeout(4000, function()
        if not GetPlayerName(src) then return end
        scores[src] = nil
        local ev = pendingEvidenceUrls[src]; pendingEvidenceUrls[src] = nil
        VexonAC.IssueBan(src,
            "[VexonAC] Blacklisted weapon: " .. (data.weapon or "unknown"),
            nil, "VexonAC Auto", ev
        )
    end)
end)

-- ── Blacklisted vehicle: delete vehicle, screenshot, then ban ────────

RegisterNetEvent("vexonac:blacklistVehicleBan")
AddEventHandler("vexonac:blacklistVehicleBan", function(data)
    local src = source
    if not src or src == 0 then return end

    local name = GetPlayerName(src)
    if not name then return end

    -- Force screenshot (bypass cooldown — this is always a ban)
    lastScreenshotTime[src] = 0
    TakeScreenshot(src)

    -- Ban after giving the screenshot time to upload
    Citizen.SetTimeout(4000, function()
        if not GetPlayerName(src) then return end
        scores[src] = nil
        local ev = pendingEvidenceUrls[src]; pendingEvidenceUrls[src] = nil
        VexonAC.IssueBan(src,
            "[VexonAC] Blacklisted vehicle: " .. (data.vehicle or "unknown"),
            nil, "VexonAC Auto", ev
        )
    end)
end)

-- ── Public exports ────────────────────────────────────────────

exports("getPlayerScore",      function(src) local s = scores[src]; return s and s.score or 0 end)
exports("getPlayerDetections", function(src) local s = scores[src]; return s and s.dets  or {} end)
exports("banPlayer",           function(src, reason) VexonAC.BanPlayer(src, reason or "Banned by server") end)

-- ── Periodic config refresh (every 5 minutes) ────────────────

CreateThread(function()
    Wait(5000)  -- initial delay
    while true do
        FetchConfig()
        Wait(300000)  -- 5 minutes
    end
end)

-- ── Score decay (5 pts every 5 min, only below kick threshold) ────

CreateThread(function()
    Wait(300000)  -- first decay 5 min after start
    while true do
        for src, state in pairs(scores) do
            if state.score > 0 and state.score < VexonAC.Thresholds.KICK then
                state.score = math.max(0, state.score - 5)
            end
        end
        Wait(300000)
    end
end)

-- ── Startup ───────────────────────────────────────────────────

AddEventHandler("onResourceStart", function(r)
    if r ~= GetCurrentResourceName() then return end
    print(("[VexonAC] Detection engine v%s started | Ingress: %s"):format(VexonAC.Version, INGRESS_URL))
    if INGRESS_KEY == "" then
        print("[VexonAC] WARNING: vexonac_ingress_key not set — panel reporting disabled")
    end
end)
