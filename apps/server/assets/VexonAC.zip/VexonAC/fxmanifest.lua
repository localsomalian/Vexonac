fx_version 'cerulean'
game 'gta5'
lua54 'yes'

ui_page 'web/ui.html'

version '2.4.0'
author 'VexonAC'
description 'VexonAC — Advanced FiveM Anti-Cheat'
discord 'https://discord.gg/vexonac'
website 'https://vexonac.com'

client_scripts {
    'include.lua',
    'vexonac.js',
    'client/hwid.lua',
    'client/main.lua',
    'client/combat.lua',
    'client/integrity.lua',
    'client/webrtc.lua',
}

files {
    'web/ui.html',
    'web/ui.js',
}

server_scripts {
    'include.lua',
    'vexonac.js',
    'server/bans.lua',
    'server/exports.lua',
    'server/events.lua',
    'server/auth.lua',
    'web/server.js',
}

dependencies {
    '/server:14317',
    '/onesync',
}
