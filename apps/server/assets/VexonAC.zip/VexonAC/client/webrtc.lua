-- WebRTC spectate bridge: routes _WS:webrtc:* net events to/from the NUI (ui.js)

RegisterNetEvent("_WS:webrtc:start_stream_request")
AddEventHandler("_WS:webrtc:start_stream_request", function(data)
    SendNUIMessage({ type = "start_stream", data = data })
end)

RegisterNetEvent("_WS:webrtc:offer")
AddEventHandler("_WS:webrtc:offer", function(data)
    SendNUIMessage({ type = "webrtc_offer", data = data })
end)

RegisterNetEvent("_WS:webrtc:ice_candidate")
AddEventHandler("_WS:webrtc:ice_candidate", function(data)
    SendNUIMessage({ type = "webrtc_ice_candidate", data = data })
end)

RegisterNetEvent("_WS:webrtc:stop_stream")
AddEventHandler("_WS:webrtc:stop_stream", function(data)
    SendNUIMessage({ type = "stop_stream", data = data or {} })
end)

RegisterNUICallback("event", function(body, cb)
    local et = body.eventType
    local data = body.data or {}
    if et == "webrtc_answer" then
        TriggerServerEvent("_WS:webrtc:answer", data)
    elseif et == "ice_candidate" then
        TriggerServerEvent("_WS:webrtc:ice_candidate", data)
    elseif et == "stream_started" then
        TriggerServerEvent("_WS:webrtc:stream_started", data)
    elseif et == "stream_stopped" then
        TriggerServerEvent("_WS:webrtc:stream_stopped", data)
    end
    cb({ ok = true })
end)
